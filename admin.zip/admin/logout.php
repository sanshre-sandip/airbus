<?php
session_start();

// Optional: check if admin
if (isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1) {
    
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
